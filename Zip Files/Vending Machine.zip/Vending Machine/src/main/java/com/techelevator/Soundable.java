package com.techelevator;

public interface Soundable {
	
	String getSound();
}
