package com.FactOrQuote.FactOrQuote;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FactOrQuoteApplication {

	public static void main(String[] args) {
		SpringApplication.run(FactOrQuoteApplication.class, args);
	}

}
